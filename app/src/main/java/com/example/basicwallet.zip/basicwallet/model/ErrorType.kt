package com.example.basicwallet.model

enum class ErrorType {
    UnknownError,
    InvalidInputError
    // Add more error types as needed
}