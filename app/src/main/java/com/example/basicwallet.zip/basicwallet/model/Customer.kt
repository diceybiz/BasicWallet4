package com.example.basicwallet.model

data class Customer(
    val id: Int,
    val name: String,
    val phone: String
)